abstract class Shape
{	
	void setColor(String color)
	{
		System.out.println("Color of Shape is :"+color);	
	}
	abstract void calculateArea();
}
class Circle extends Shape
{
	double radius=45;
	double area;
	void calculateArea()
	{
		area=3.14*radius*radius;
		System.out.println("Area of Circle :"+area);
	}
	void circleMet()
	{
		System.out.println("Circle Method");
	}
}
class Square extends Shape
{
	double side=31;
	double area;
	void calculateArea()
	{
		area=side*side;
		System.out.println("Area of Square :"+area);
	}
}
class AbstractDemo
{
	public static void main(String as[])
	{
		// Shape S1=new Shape(); cannot be instaniated
		Circle C=new Circle();
		C.setColor("Green");
		C.calculateArea();
		//C.circleMet(); //variable C of type Shape (Shape C=new Circle())
		
		Shape S=new Square();
		S.setColor("Yellow");
		S.calculateArea();
	}
}