import java.util.*;
class Best_Raiders
{
    public static void main(String[] args)
    {
    Scanner ip= new Scanner(System.in);
    ArrayList<String> a = new ArrayList<String>();
    System.out.println("Enter the top 5 raiders of PKL Season 3");
    for(int i=1;i<=5;i++)
    {
        String s = ip.nextLine();
        a.add(s);
    }
    ArrayList<String> b= new ArrayList<String>();
     System.out.println("Enter the top 5 raiders of PKL Season 4");
    for(int i=1; i<=5;i++)
    {
        String c=ip.nextLine();
        b.add(c);
    }
    a.retainAll(b);
    System.out.println("Best Raiders");
    Iterator q = a.iterator();
    
    while (q.hasNext())
    {
        System.out.println(q.next());
    }
}
}
