import java.util.*;
public class CollectionList2Sorting {
public static void main(String args[])
{
	ArrayList<Integer> arr=new ArrayList<Integer>();
	Scanner s=new Scanner(System.in);
	int n=s.nextInt();
	for(int i=0;i<n;i++)
	{
		int x=s.nextInt();
		arr.add(x);
	}
	Collections.sort(arr);
	Iterator itr=arr.iterator();
	  while(itr.hasNext())
	  {
		  System.out.println(itr.next());
	  }
}
}
