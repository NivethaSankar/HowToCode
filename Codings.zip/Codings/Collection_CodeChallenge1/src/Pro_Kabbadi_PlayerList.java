import java.util.*;
import java.lang.*;

public class Pro_Kabbadi_PlayerList
{
    
    public static void main(String args[])
    { 
        ArrayList<String> io=new ArrayList<String>();
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        String c;
        int num=Integer.parseInt(s);
        for(int i=0;i<num;i++)
        {
            io.add(sc.nextLine());
        }
        do
        {
            System.out.println("Menu");
             System.out.println("1.Insert Players");
              System.out.println("2.Delete Players");
              String p=sc.nextLine();
              int no=Integer.parseInt(p);
              String name=sc.nextLine();
              if(no==1)
              {
                  io.add(name);
                  System.out.println("Player details after insertion");
                  for(String k:io)
                  {
                      System.out.println(k);
                  }
              }
              else
              {
                  io.remove(name);
                  System.out.println("Player details after deletion");
                  for(String k:io)
                  {
                      System.out.println(k);
                  }
              }
              System.out.println("Do you want to continue");
              c=sc.nextLine();
        }
        while(c.equals("Yes"));
        sc.close();
        }
}
