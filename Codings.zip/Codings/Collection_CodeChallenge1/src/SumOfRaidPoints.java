import java.util.*;
class SumOfRaidPoints
{
    public static void main(String args[])
    {
        int sum=0;
        Scanner sc = new Scanner(System.in);
        int n=sc.nextInt();
        ArrayList<Integer> arr = new ArrayList(n);
        for(int i=0;i<n;i++)
        {
            arr.add(sc.nextInt());
            
        }
        for(int i:arr)
        {
            String num=String.valueOf(i);
            
            for(int c=0;c<num.length();c++)
            {
                if(num.charAt(c)=='5')
                break;
                else
                sum=sum+Integer.parseInt(String.valueOf(num.charAt(c)));
            }
        }
        System.out.println(sum);
    }
}

