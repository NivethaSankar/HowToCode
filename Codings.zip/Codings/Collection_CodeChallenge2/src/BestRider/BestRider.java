package BestRider;

import java.util.Scanner;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		TreeSet<String> ts=new TreeSet<String>();
		Scanner sc=new Scanner(System.in);
		int n=Integer.parseInt(sc.nextLine());
		for(int i=0;i<n;i++)
		{
			String s=sc.nextLine();
			ts.add(s);
		}
		for(String str:ts)
		{
			System.out.println(str);
		}
		
	}

}
