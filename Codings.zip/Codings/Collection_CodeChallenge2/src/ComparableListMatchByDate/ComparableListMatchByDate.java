package ComparableListMatchByDate;

import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;  
import java.util.Date; 
import java.util.Calendar;

class Main
{
    public static void main(String args[])throws Exception
    {
        BufferedReader s=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("");
     
                TreeSet<Match> ts1 = new TreeSet<Match>();
    System.out.println("Enter the number of matches");
    
 int n=Integer.parseInt(s.readLine());
for(int i=0;i<n;i++)
        {
           Match m=new Match();
           System.out.println("Enter match date in (MM-dd-yyyy)");
           String te=s.readLine();
          Date d= new SimpleDateFormat("MM-dd-yyyy").parse(te);         
         
           m.setMatchDate(d);
           System.out.println("Enter Team 1");
           m.setTeamOne(s.readLine());           
           System.out.println("Enter Team 2");
           m.setTeamTwo(s.readLine());
           System.out.println("Enter venue");
           m.setVenue(s.readLine());
           ts1.add(m);
           
        }          
        

SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");
    System.out.println("Match Details");
     Iterator iterator = ts1.iterator();       
     while (iterator.hasNext()) 
     {
         Match r1=(Match)iterator.next();
                 System.out.println("Team 1 "+r1.getTeamOne()+"\nTeam 2 "+r1.getTeamTwo()+"\nMatch held on "+sdf1.format(r1.getMatchDate())+"\nMatch held at "+r1.getVenue());
     }
    }
                
}












package ComparableListMatchByDate;

import java.text.SimpleDateFormat;  
import java.util.Date; 
//import java.util.Date; 
import java.util.Calendar;
class Match implements Comparable<Match>
{
    Date matchDate;
    String venue,teamOne,teamTwo;
    public Date getMatchDate() {
                return matchDate;
                }
    
    public void setMatchDate(Date matchDate) {
                this.matchDate = matchDate; 
                }
                public void setVenue(String venue)
                {
                    this.venue=venue;
                }
                public String getVenue()
                {
                    return venue;
                }
                public String getTeamOne() {
                                return teamOne;
                }
                public void setTeamOne(String teamOne) {
                                this.teamOne = teamOne;
                }
                public String getTeamTwo() {
                                return teamTwo;
                }
                public void setTeamTwo(String teamTwo) {
                                this.teamTwo = teamTwo;
                }
    
    public int compareTo(Match m){
    if(m.matchDate.after(matchDate))
                {
                                return -1;
                }
                else if(m.matchDate.before(matchDate))    
                {
                                return 1;
                }              
                                return 0;
                
}
    
}