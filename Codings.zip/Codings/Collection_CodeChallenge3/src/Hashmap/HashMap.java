package Hashmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.event.TreeExpansionEvent;

public class Main {

    public static void main(String[] args) {								
				Scanner sc = new Scanner(System.in);
				
				System.out.println("Enter the number of players");
				int players = Integer.parseInt(sc.nextLine());
				
				HashMap<String, Long> playerMap = new HashMap<String, Long>();
				
				for(int i = 0; i < players; i++){
					System.out.println("Enter the details of the player " + (i+1));
					String playerName = sc.nextLine();
					long runs = Long.parseLong(sc.nextLine());
					
					playerMap.put(playerName, runs);
				}
				
				Set<String> keys = playerMap.keySet();
				
				long max = 0;
				String bestPlayer = new String();
				
				for(String p :keys){
					System.out.println("Player Name :"+p);
					if(playerMap.get(p) > max){
						max = playerMap.get(p);
						bestPlayer = p;
						System.out.println("Best Player Name :"+bestPlayer);
					}
				}
								
					System.out.println(bestPlayer);
					sc.close();	
	}
}

