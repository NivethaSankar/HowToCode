package com.rays.dao;

import java.util.List;

import com.rays.model.Employee;

public interface EmployeeDAO {
	
	public int saveEmployee(Employee emp);
	public int updateEmployee(Employee emp);
	public List<Employee> getAllEmployee();
	public int deleteEmployee(int empid);
	public Employee getByEmployeeId(int empid);

}
