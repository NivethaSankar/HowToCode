import java.util.*;
import java.text.*;

public class DateDemo1 {

   public static void main(String args[])throws ParseException {
      Date dNow = new Date( );	  
	  SimpleDateFormat ft1 = new SimpleDateFormat ("yyyy-MM-dd");
	  SimpleDateFormat ft2 = new SimpleDateFormat ("HH:mm:ss");
      SimpleDateFormat ft = new SimpleDateFormat ("E yyyy.MM.dd 'at' HH:mm:ss a zzz");

      System.out.println("Current Date with Default Format : "+dNow);
      System.out.println("Current Date: " + ft.format(dNow));
	  System.out.println("Current Date: " + ft1.format(dNow));
	  
	  Date str=ft1.parse("2007-02-19");	 
	  System.out.println(str);
	
   }
}