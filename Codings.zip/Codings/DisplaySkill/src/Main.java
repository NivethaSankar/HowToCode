import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

public class Main {

	public static void main(String[] args) throws SQLException {
		
		SkillDAO sd=new SkillDAO();
		List<Skill> listSkill=sd.listAllSkills();
		System.out.println("List of all skills");
		int i=0;
		for(Skill s:listSkill)
		{
			System.out.println((++i)+") "+s.getSkillName());
		}
		
		Iterator<Skill> it=listSkill.iterator();
		while(it.hasNext())
		{
			Skill ss=it.next();
			System.out.println((++i)+") "+ss.getSkillName());
		}

	}

}
