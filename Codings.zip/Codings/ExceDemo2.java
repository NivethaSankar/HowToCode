import java.io.*;
class ExceDemo2
{
	public static void main(String as[])throws IOException
	{
		System.out.println("Main Starts Here...");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Two Numbers:");
		try{
		int a=Integer.parseInt(br.readLine());
		int b=Integer.parseInt(br.readLine());		
		int c=divMet(a,b);
		System.out.println("Answer C:"+c);		
		}catch(Exception e)
		{
			System.out.println("Exception Handled...");
			System.out.println(e);
			System.out.println(e.getClass());
			System.out.println(e.getMessage());			
		}				
		System.out.println("Main Ends Here...");
	}
	static int divMet(int a,int b)
	{
		if(b==0)
			throw new ArithmeticException("You cannot divide by zeero...");
		else
			return a/b;
	}
}