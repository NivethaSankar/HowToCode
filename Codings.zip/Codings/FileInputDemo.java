import java.io.*;
class FileInputDemo
{
	public static void main(String as[])throws FileNotFoundException,IOException
	{
		FileInputStream fis=new FileInputStream("C:\\Users\\t-Mohamed\\Downloads\\cognizant.png");
		int a;
		//StringBuffer data=new StringBuffer();
		while((a=fis.read())!=-1)
		{
			System.out.print((char)a);
			//data.append(""+(char)a);
		}
		//System.out.print(data);
	}
}