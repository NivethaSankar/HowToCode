import java.io.*;
class FileOutputDemo
{
	public static void main(String as[])throws FileNotFoundException,IOException
	{
		try(FileInputStream fis=new FileInputStream("C:\\Users\\t-Mohamed\\Downloads\\cognizant.png");
		FileOutputStream fos=new FileOutputStream("d:\\newone.raffic",true);)
		{
		int a;
		
		while((a=fis.read())!=-1)
		{			
				fos.write(a);
		}
		System.out.println("Successfully Completed...");
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}

//C:\\Users\\t-Mohamed\\Downloads\\cognizant.png