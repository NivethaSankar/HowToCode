import java.util.*;
class FirstPro
 {
	public static void main(String as[])
	{
		System.out.println("Welcome to Java World");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Name:");
		String name=sc.next();
		System.out.println("Enter Your room no:");
		int room=sc.nextInt();
		System.out.println("Your Name:"+name);
		System.out.println("Your Room No:"+room);
	}
 }