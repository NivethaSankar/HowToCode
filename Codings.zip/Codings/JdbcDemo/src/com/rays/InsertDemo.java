package com.rays;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.mysql.jdbc.Driver;

public class InsertDemo {

	public static void main(String[] args)throws IOException {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Employee Details:");
		System.out.println("Emp ID:");
		int empid=Integer.parseInt(br.readLine());
		System.out.println("EMp Name:");
		String empname=br.readLine();
		System.out.println("Emp Age:");
		int empage=Integer.parseInt(br.readLine());
		System.out.println("Emp Salary");
		double empsalary=Integer.parseInt(br.readLine());
		
		try {
			DriverManager.registerDriver(new Driver());
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cts_demo", "root", "root");
			PreparedStatement ps=con.prepareStatement("insert into employee values(?,?,?,?)");
			ps.setInt(1, empid);
			ps.setString(2, empname);
			ps.setInt(3, empage);
			ps.setDouble(4, empsalary);
			int count=ps.executeUpdate();
			if(count>=1)
				System.out.println("Employee Details Inserted...");
			else
				System.out.println("Error with your Data...");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
