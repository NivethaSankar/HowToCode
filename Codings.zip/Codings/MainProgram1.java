class Calculator
{
	int num1,num2;
	void addition()
	{
		int result=num1+num2;
		System.out.println("The Sum of the Two numbers "+num1+" and "+num2+" is "+result);
	}
	void subtraction()
	{
		int result=num1-num2;
		System.out.println("The Sub of the Two numbers "+num1+" and "+num2+" is "+result);
	}
	void printsmaller()
	{
		if(num1<num2)
		  System.out.println("The smallest of the Two numbers "+num1+" and "+num2+" is "+num1);
		else
		  System.out.println("The smallest of the Two numbers "+num1+" and "+num2+" is "+num2);		
	}
}
class MainProgram1
	{
		public static void main(String as[])
		{
			Calculator cal_obj=new Calculator();
			cal_obj.num1=12;
			cal_obj.num2=8;
			cal_obj.addition();
			cal_obj.subtraction();
			cal_obj.printsmaller();
		}
	} 