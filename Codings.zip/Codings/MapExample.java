import java.util.*;  

class MapExample{  

public static void main(String args[]){  
	//Creating a Map
	Map<Integer,String> map=new HashMap<Integer,String>();
	// Adding key and value to the map
	map.put(100,"TOM");  
	map.put(101,"JOHN");  
	map.put(102,"SAM");  
	//Iterate to print the key and value.
	for(Map.Entry m:map.entrySet()){  
		System.out.println(m.getKey()+" "+m.getValue());  
	}  
}  
}
