  import java.util.*;
class MatchBO {
    
	public void printAllMatchDetails(Match MatchList[])
	{
		
        System.out.format("%-15s %-15s %-15s %-15s %-15s %s\n","Date","Team1","Team2","Venue","Status","Winner");
        for(int i=0;i<MatchList.length;i++)
        {
        	System.out.println(MatchList[i].toString());
        }
		
	}
	
	

	public void printMatchDetailsWithOutcomeStatus(Match MatchList[], String outcomeStatus) {
		
			
            System.out.format("%-15s %-15s %-15s %-15s %-15s %s\n","Date","Team1","Team2","Venue","Status","Winner");
			int count=0;
            for(int i=0;i<MatchList.length;i++)
            {
            	if(MatchList[i].outcome.getStatus().equals(outcomeStatus))
            	{
            		System.out.println(MatchList[i].toString());
            	}
            }
            if(count==0)
            	System.out.println("Status not found");
		
	}
	
	public void printMatchDetailsWithOutcomeWinnerTeam(Match MatchList[], String outcomeWinnerTeam)
	{
        System.out.format("%-15s %-15s %-15s %-15s %-15s %s\n","Date","Team1","Team2","Venue","Status","Winner");
				
        int count=0;
        for(int i=0;i<MatchList.length;i++)
        {
        	if(MatchList[i].outcome.getWinnerTeam().equals(outcomeWinnerTeam))
        	{
        		System.out.println(MatchList[i].toString());
        	}
        }
        if(count==0)
        	System.out.println("Winner Team not found");
		
	}
	

}


