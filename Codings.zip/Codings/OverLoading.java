class OverLoading
	{
		public static void main(String as[])
		{
			AreaDemo ad=new AreaDemo();
			ad.areaMet(4.5);
			ad.areaMet(4,5);
			ad.areaMet(45);
		}
	}