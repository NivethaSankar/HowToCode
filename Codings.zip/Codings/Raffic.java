class FirstPro
 {
	public static void main(String as[])
	{
		System.out.println("Welcome to Java World");
	}
 }