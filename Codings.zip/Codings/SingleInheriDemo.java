class Parent
{
	int a,b;
	Parent()
	{
		System.out.println("In Parent Constructor");		
	}
	void parentMet()
	{
		System.out.println("In Parent Method");
	}
}
class Child extends Parent
{	
	Child()
	{
		super();
		System.out.println("In Child Constructor");
	}
	void childMet()
	{
		int c=a+b;
		System.out.println("In Child Method c=:"+c);
	}
}
class SingleInheriDemo
{
	public static void main(String as[])
	{
		Child C=new Child();
		C.a=100;
		C.b=200;
		C.childMet();
		C.parentMet();
	}
}