class StaticDemo
{
	public static void main(String as[])
	{
		StaticExample se1=new StaticExample();
		StaticExample se2=new StaticExample();
		StaticExample se3=new StaticExample();
		se1.a=100;
		se1.b=200;
		se2.a=300;
		se2.b=400;
		se3.a=500;
		se3.b=600;
		se1.printValue();
		se2.printValue();
		se3.printValue();
		
	}
}