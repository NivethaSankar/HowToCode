class StringBufferDemo
{
	public static void main(String as[])
	{
		StringBuffer sb1=new StringBuffer();				
		StringBuffer sb2=new StringBuffer("Java is a platform independent language");				
		
		System.out.println(sb1);
		System.out.println(sb2);
		System.out.println(sb1.length());
		System.out.println(sb2.length());
		System.out.println(sb1.capacity());
		System.out.println(sb2.capacity());
		System.out.println(sb2.append("Pure OOPS Language"));
		System.out.println(sb2);
		System.out.println(sb2.length());
		System.out.println(sb2.capacity());
		System.out.println(sb2.insert(5,"Thread"));	
		System.out.println(sb2.delete(5,11));
		System.out.println(sb2.replace(0,4,"JAVA"));
		System.out.println(sb2);
		System.out.println(sb2.reverse());
		System.out.println(sb2);
	}
}