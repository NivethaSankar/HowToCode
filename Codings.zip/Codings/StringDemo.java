class StringDemo
{
	public static void main(String as[])
	{
		String msg1="CTS";
		String msg2="CTS";
		String msg3=new String("CTS");
		String msg4=new String("CTS");
		
		if(msg1==msg2)
			System.out.println("Hi");
		
		if(msg3==msg4)
			System.out.println("Hello");
	}
}