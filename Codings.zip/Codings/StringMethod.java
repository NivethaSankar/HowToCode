class StringMethod
{
	public static void main(String as[])
	{
		String msg1="java is a platform java independent java language";		
		String msg2="java is a platform independent language";	
		char c[]={'j','a','v','a',' ','w','e','l','c','o','m','e','s',' ','y','o','u'};
		String msg3=new String(c);
		String msg4=new String(c,2,10);
		
		System.out.println(msg1.length());
		System.out.println(msg1.charAt(6));
		System.out.println(msg1.equals(msg2));
		System.out.println(msg1.equalsIgnoreCase(msg2));
		System.out.println(msg1.indexOf('a'));
		System.out.println(msg1.indexOf('a',11));
		System.out.println(msg1.lastIndexOf('a'));
		System.out.println(msg1.lastIndexOf('a',34));
		System.out.println(msg1.substring(5));
		System.out.println(msg1.substring(5,20));
		System.out.println(msg1.startsWith("java"));
		System.out.println(msg1.endsWith("uage"));
		System.out.println(c);
		System.out.println(msg3);
		System.out.println(msg4);
		System.out.println(msg3.concat(msg1));
		System.out.println(msg3);
		System.out.println(msg1.replace('a','@'));
		System.out.println(msg1.replace("java","JAVA"));			
		System.out.println(msg1);
	}
}