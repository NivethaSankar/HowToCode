
public class PrinterThread implements Runnable{	
	String A;
	String B;
	public PrinterThread(String A, String B) {
		this.A=A;
		this.B=B;
		Thread T=new Thread(this);
		T.start();
	}
	@Override
	public void run() {
		try {
			StringPrinter.printString(A, B);
		} catch (InterruptedException e) {
			System.out.println(e);			
		}
		
	}
	

}
