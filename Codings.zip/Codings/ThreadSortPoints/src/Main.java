import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws InterruptedException {
    	// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		SortPoints []threadsOfScores = new SortPoints[2];
		
		String matchType;
		String scores;
	
		//Thread 1 creation
		System.out.println("Enter the match type");
		matchType = sc.nextLine();
		System.out.println("Enter the points");
		scores = sc.nextLine();
		
		threadsOfScores[0] = new SortPoints(matchType, scores);
		
		threadsOfScores[0].start();
		
		//Thread 2 creation
		System.out.println("Enter the match type");
		matchType = sc.nextLine();
		System.out.println("Enter the points");
		scores = sc.nextLine();
		
		threadsOfScores[1] = new SortPoints(matchType, scores);
		
		//Don't start the second thread unless the first is complete
		threadsOfScores[0].join();
		threadsOfScores[1].start();
		
		
		
		threadsOfScores[1].join();
		//Wait till all threads are done
		if(!threadsOfScores[1].isAlive()){
				
			for(int i = 0; i < 2; i++){
				System.out.println("Match : " + threadsOfScores[i].getMatchType());
				Integer []scoreArray = threadsOfScores[i].getScores();
				for(int i1 :scoreArray)
					System.out.println(i1);	
			}
				
		}

		sc.close();
    }
}